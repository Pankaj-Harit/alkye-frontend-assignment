import React from 'react'

function HeaderComponent() {
    return (
        <header className='fixed z-10 top-0'>
            <div className='mx-auto flex items-center w-screen relative h-36 px-10 text-white border-b-2'>
                <ul className='flex items-center space-x-10 '>
                    <li><a href='' className='uppercase'>Projects</a></li>
                    <li><a href='' className='uppercase'>Expertise</a></li>
                    <li><a href='' className='uppercase'>About Us</a></li>
                    <li><a href='' className='uppercase'>People</a></li>
                </ul>
                <a className='relative lg:absolute lg:top-[50%] lg:left-[50%] lg:-translate-x-2/4 lg:-translate-y-2/4'><img src='./Logo.png' /></a>
                <ul className='flex space-x-10 justify-end flex-1'>
                    <li><a href='' className='uppercase'>Careers</a></li>
                    <li><a href='' className='uppercase'>Au</a></li>
                </ul>
            </div>
        </header>
    )
}

export default HeaderComponent