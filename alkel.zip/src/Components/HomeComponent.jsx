import React from 'react'

function HomeComponent() {
    return (
        <div className='h-screen relative'>
            <div>
                <div className="absolute inset-0 bg-cover z-[-1]" style={{ backgroundImage: "url(./HomePageBackground.png)" }}></div>
                <div className='absolute bottom-32 left-10 text-white'>
                    <p className='text-sm'>Home / Why work with us</p>
                    <h5 className='text-4xl'>Headline #1</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>
                <div className='absolute bottom-5 right-10 text-white'>
                    <span className='border rounded-[50%] w-6 h-6 inline-block text-center me-2'>P</span>
                    <span className='border rounded-[50%] w-6 h-6 inline-block text-center '>N</span>
                </div>
            </div>
        </div>
    )
}

export default HomeComponent