import React from 'react'

function FeedBackComponent() {
    return (
        <div className='bg-themecolor pt-10 '>
            <div className='flex text-white  max-w-8xl mx-auto p-10 relative'>
                <div>
                    <img src='./feeback.png' />
                </div>
                <div className='p-10'>
                    <div className='p-5 '>
                        <p className={`relative before:absolute before:content-['\"'] before:text-[#F36F2B] before:text-4xl before:w-16 before:h-16 before:-top-5 before:-left-5 z-20`}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales turpis et lacinia fermentum. Curabitur vestibulum at arcu sed blandit. In consequat euismod purus nec imperdiet.
                            Title
                            Name</p>
                        <div className='mt-5'>
                            <p className=''>Title</p>
                            <p>Name</p>
                        </div>
                        <div className='text-white mt-5'>
                            <span className='border rounded-[50%] w-6 h-6 inline-block text-center me-2'>P</span>
                            <span className='ms-5'>Read my story</span>
                        </div>
                        <div className='absolute bottom-10 right-10 text-white'>
                            <span className='border rounded-[50%] w-6 h-6 inline-block text-center me-2'>P</span>
                            <span className='border rounded-[50%] w-6 h-6 inline-block text-center '>N</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default FeedBackComponent