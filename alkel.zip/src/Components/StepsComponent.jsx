import React from 'react'

function StepsComponent() {
    return (
        <div className='grid grid-cols-1 md:grid-cols-3'>
            <div className='bg-themecolor text-white pt-5 p-10 ps-10 border-b-2 md:border-r-2 border-black relative'>
                <div>
                    <header className='mb-3 text-gray-400 text-xl'>01</header>
                    <p>We stay connected</p>
                </div>
                <div className='absolute bottom-5 right-5 text-white'>
                    <span className='border rounded-[50%] w-6 h-6 inline-block text-center me-2'>P</span>
                </div>
            </div>
            <div className='bg-themecolor text-white pt-5 p-10 ps-10 border-b-2 md:border-r-2 border-black relative'>
                <div>
                    <header className='mb-3 text-gray-400 text-xl'>02</header>
                    <p>We believe in diversity & inclusion</p>
                </div>
                <div className='absolute bottom-5 right-5 text-white'>
                    <span className='border rounded-[50%] w-6 h-6 inline-block text-center me-2'>P</span>
                </div>
            </div>
            <div className='bg-themecolor text-white pt-5 p-10 ps-10 border-b-2 md:border-r-2 border-black relative'>
                <div>
                    <header className='mb-3 text-gray-400 text-xl'>03</header>
                    <p>We celebrate success</p>
                </div>
                <div className='absolute bottom-5 right-5 text-white'>
                    <span className='border rounded-[50%] w-6 h-6 inline-block text-center me-2'>P</span>
                </div>
            </div>
        </div>
    )
}

export default StepsComponent